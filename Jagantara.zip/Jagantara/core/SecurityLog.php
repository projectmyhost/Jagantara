<?php

class SecurityLog {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function log(string $action, string $details = '', ?string $ip = null, ?string $deviceFingerprint = null): void {
        $ip = $ip ?? Security::getClientIp();
        $device = $deviceFingerprint ?? Security::getDeviceFingerprint();
        $userId = currentUserId();

        try {
            $stmt = $this->db->prepare(
                'INSERT INTO security_logs (user_id, ip_address, device_fingerprint, action, details, created_at)
                 VALUES (?, ?, ?, ?, ?, NOW())'
            );
            $stmt->execute([$userId, $ip, $device, $action, $details]);
        } catch (\Exception $e) {
            error_log('SecurityLog write failed: ' . $e->getMessage());
        }
    }

    public function logBruteForce(string $ip, string $emailDomain): void {
        $this->log('brute_force_detected', json_encode(['email_domain' => $emailDomain]), $ip);
    }

    public function logSuspiciousRegistration(string $ip, string $device): void {
        $this->log('suspicious_registration', 'Registration limit exceeded', $ip, $device);
    }

    public function logInvalidCsrf(string $path): void {
        $this->log('invalid_csrf', json_encode(['path' => $path]));
    }

    public function logUnauthorizedAccess(string $path, ?int $userId = null): void {
        $this->log('unauthorized_access', json_encode(['path' => $path, 'user_id' => $userId]));
    }

    public function logSuspiciousUpload(string $filename, string $reason): void {
        $this->log('suspicious_upload', json_encode(['filename' => $filename, 'reason' => $reason]));
    }

    public function logIdorAttempt(string $resource, int $targetId, int $requesterId): void {
        $this->log('idor_attempt', json_encode([
            'resource' => $resource,
            'target_id' => $targetId,
            'requester_id' => $requesterId,
        ]));
    }
}
