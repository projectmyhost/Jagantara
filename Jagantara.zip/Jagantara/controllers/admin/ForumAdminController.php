<?php

class ForumAdminController extends Controller {
    private ForumPost $postModel;
    private ForumComment $commentModel;

    public function __construct() {
        parent::__construct();
        $this->postModel = new ForumPost();
        $this->commentModel = new ForumComment();
    }

    public function index(): void {
        $this->requireRole(ROLE_ADMIN);

        $posts = $this->postModel->query(
            "SELECT fp.*, p.full_name, p.username, u.email, c.name AS category_name,
                    (SELECT COUNT(*) FROM forum_comments fc WHERE fc.post_id = fp.id AND fc.deleted_at IS NULL) AS comment_count
             FROM forum_posts fp
             LEFT JOIN users u ON u.id = fp.user_id
             LEFT JOIN profiles p ON p.user_id = fp.user_id
             LEFT JOIN categories c ON c.id = fp.category_id
             WHERE fp.deleted_at IS NULL
             ORDER BY fp.created_at DESC"
        );

        $this->view('admin.forum.index', [
            'pageTitle'  => 'Moderasi Forum - ' . APP_NAME,
            'adminTitle' => 'Moderasi Forum Diskusi',
            'posts'      => $posts,
        ], 'admin');
    }

    public function show(string|int $id): void {
        $this->requireRole(ROLE_ADMIN);
        $id = (int)$id;

        $post = $this->postModel->findWithDetails($id);
        if (!$post) {
            $this->abort(404, 'Topik tidak ditemukan.');
        }

        $comments = $this->commentModel->getByPost($id);

        $this->view('admin.forum.show', [
            'pageTitle'  => 'Detail Moderasi Forum #' . $id . ' - ' . APP_NAME,
            'adminTitle' => 'Moderasi Topik #' . $id,
            'post'       => $post,
            'comments'   => $comments,
        ], 'admin');
    }

    public function delete(string|int $id): void {
        $this->requireRole(ROLE_ADMIN);
        $this->validateCsrf();
        $id = (int)$id;

        $post = $this->postModel->find($id);
        if (!$post) {
            $this->abort(404, 'Topik tidak ditemukan.');
        }

        $this->postModel->delete($id);
        $this->audit()->log('admin_delete_forum_post', 'forum_post', $id, ['title' => $post['title']]);

        setFlash('success', 'Topik diskusi berhasil dihapus oleh admin.');
        $this->redirect('admin/forum');
    }

    public function deleteComment(string|int $id): void {
        $this->requireRole(ROLE_ADMIN);
        $this->validateCsrf();
        $id = (int)$id;

        $comment = $this->commentModel->find($id);
        if (!$comment) {
            $this->abort(404, 'Komentar tidak ditemukan.');
        }

        $this->commentModel->delete($id);
        $this->audit()->log('admin_delete_forum_comment', 'forum_comment', $id);

        setFlash('success', 'Komentar berhasil dihapus oleh admin.');
        $this->redirect('admin/forum/' . $comment['post_id']);
    }
}
