<?php

class AuditLogAdminController extends Controller {

    public function index(): void {
        $this->requireRole(ROLE_ADMIN);

        $page = currentPage();
        $action = trim((string)$this->query('action', ''));
        $offset = ($page - 1) * ADMIN_ITEMS_PER_PAGE;

        $db = Database::getConnection();

        $where = [];
        $params = [];

        if ($action !== '') {
            $where[] = 'al.action LIKE ?';
            $params[] = "%$action%";
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $countStmt = $db->prepare("SELECT COUNT(*) FROM audit_logs al $whereClause");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $stmt = $db->prepare(
            "SELECT al.*, u.email, p.username, p.full_name
             FROM audit_logs al
             LEFT JOIN users u ON u.id = al.user_id
             LEFT JOIN profiles p ON p.user_id = al.user_id
             $whereClause
             ORDER BY al.created_at DESC
             LIMIT ? OFFSET ?"
        );
        $stmt->execute([...$params, ADMIN_ITEMS_PER_PAGE, $offset]);
        $logs = $stmt->fetchAll();

        $pagination = [
            'data'         => $logs,
            'total'        => $total,
            'per_page'     => ADMIN_ITEMS_PER_PAGE,
            'current_page' => $page,
            'total_pages'  => (int)ceil($total / ADMIN_ITEMS_PER_PAGE),
            'has_prev'     => $page > 1,
            'has_next'     => $page < ceil($total / ADMIN_ITEMS_PER_PAGE),
        ];

        $this->view('admin.audit_logs.index', [
            'pageTitle'  => 'Audit Logs Sistem - ' . APP_NAME,
            'adminTitle' => 'Audit Logs Sistem',
            'logs'       => $logs,
            'pagination' => $pagination,
            'action'     => $action,
        ], 'admin');
    }

    public function securityLogs(): void {
        $this->requireRole(ROLE_ADMIN);

        $page = currentPage();
        $offset = ($page - 1) * ADMIN_ITEMS_PER_PAGE;
        $db = Database::getConnection();

        $countStmt = $db->query("SELECT COUNT(*) FROM security_logs");
        $total = (int)$countStmt->fetchColumn();

        $stmt = $db->prepare(
            "SELECT sl.*, u.email, p.username
             FROM security_logs sl
             LEFT JOIN users u ON u.id = sl.user_id
             LEFT JOIN profiles p ON p.user_id = sl.user_id
             ORDER BY sl.created_at DESC
             LIMIT ? OFFSET ?"
        );
        $stmt->execute([ADMIN_ITEMS_PER_PAGE, $offset]);
        $logs = $stmt->fetchAll();

        $pagination = [
            'data'         => $logs,
            'total'        => $total,
            'per_page'     => ADMIN_ITEMS_PER_PAGE,
            'current_page' => $page,
            'total_pages'  => (int)ceil($total / ADMIN_ITEMS_PER_PAGE),
            'has_prev'     => $page > 1,
            'has_next'     => $page < ceil($total / ADMIN_ITEMS_PER_PAGE),
        ];

        $this->view('admin.audit_logs.security_logs', [
            'pageTitle'  => 'Security Logs - ' . APP_NAME,
            'adminTitle' => 'Security Event Logs',
            'logs'       => $logs,
            'pagination' => $pagination,
        ], 'admin');
    }
}
