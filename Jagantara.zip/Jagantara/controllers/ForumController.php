<?php

class ForumController extends Controller {
    private ForumPost $postModel;
    private ForumComment $commentModel;
    private Category $categoryModel;
    private RateLimit $rateLimiter;

    public function __construct() {
        parent::__construct();
        $this->postModel = new ForumPost();
        $this->commentModel = new ForumComment();
        $this->categoryModel = new Category();
        $this->rateLimiter = new RateLimit();
    }

    public function index(): void {
        $page = currentPage();
        $categoryId = (int)$this->query('category', 0);
        $search = trim((string)$this->query('q', ''));

        $filters = [
            'category_id' => $categoryId,
            'search'      => $search,
        ];

        $postsData = $this->postModel->listPublic($filters, $page, ITEMS_PER_PAGE);
        $categories = $this->categoryModel->getActive();

        $this->view('forum.index', [
            'pageTitle'  => 'Forum Diskusi Lingkungan - ' . APP_NAME,
            'posts'      => $postsData['data'],
            'pagination' => $postsData,
            'categories' => $categories,
            'filters'    => $filters,
        ]);
    }

    public function show(string|int $id): void {
        $id = (int)$id;
        $post = $this->postModel->findWithDetails($id);

        if (!$post) {
            $this->abort(404, 'Topik diskusi tidak ditemukan.');
        }

        $comments = $this->commentModel->getByPost($id);

        $this->view('forum.show', [
            'pageTitle' => e($post['title']) . ' - Forum ' . APP_NAME,
            'post'      => $post,
            'comments'  => $comments,
        ]);
    }

    public function create(): void {
        $this->requireAuth();
        $categories = $this->categoryModel->getActive();

        $this->view('forum.create', [
            'pageTitle'  => 'Buat Topik Diskusi Baru - ' . APP_NAME,
            'categories' => $categories,
        ]);
    }

    public function store(): void {
        $this->requireAuth();
        $this->validateCsrf();

        $userId = (int)currentUserId();

        if (!$this->rateLimiter->checkForum($userId)) {
            setFlash('error', 'Batas pengiriman posting tercapai. Silakan coba lagi beberapa saat lagi.');
            $this->redirect('forum');
        }

        $input = $this->allInput();

        $validator = Validator::make($input);
        $validator->required('title', 'Judul Diskusi')
                  ->minLength('title', 5, 'Judul Diskusi')
                  ->maxLength('title', 200, 'Judul Diskusi')
                  ->required('content', 'Isi Diskusi')
                  ->minLength('content', 10, 'Isi Diskusi');

        if ($validator->fails()) {
            setFlash('error', $validator->getFirstError());
            $this->view('forum.create', [
                'pageTitle'  => 'Buat Topik Diskusi Baru',
                'categories' => $this->categoryModel->getActive(),
                'values'     => $input,
                'errors'     => $validator->getErrors(),
            ]);
            return;
        }

        $postId = $this->postModel->create([
            'user_id'     => $userId,
            'title'       => trim($input['title']),
            'content'     => trim($input['content']),
            'category_id' => !empty($input['category_id']) ? (int)$input['category_id'] : null,
        ]);

        $this->audit()->log('create_forum_post', 'forum_post', $postId, ['title' => trim($input['title'])]);

        setFlash('success', 'Topik diskusi berhasil diterbitkan.');
        $this->redirect('forum/' . $postId);
    }

    public function comment(string|int $id): void {
        $this->requireAuth();
        $this->validateCsrf();

        $id = (int)$id;
        $userId = (int)currentUserId();

        $post = $this->postModel->find($id);
        if (!$post) {
            $this->abort(404, 'Topik tidak ditemukan.');
        }

        if (!$this->rateLimiter->checkComment($userId)) {
            setFlash('error', 'Terlalu banyak komentar dalam waktu singkat. Silakan tunggu beberapa saat.');
            $this->redirect('forum/' . $id);
        }

        $content = trim((string)$this->input('content', ''));
        if (empty($content) || mb_strlen($content) < 2) {
            setFlash('error', 'Komentar tidak boleh kosong.');
            $this->redirect('forum/' . $id);
        }

        $commentId = $this->commentModel->create([
            'post_id' => $id,
            'user_id' => $userId,
            'content' => $content,
        ]);

        $this->audit()->log('create_forum_comment', 'forum_comment', $commentId, ['post_id' => $id]);

        setFlash('success', 'Komentar Anda telah ditambahkan.');
        $this->redirect('forum/' . $id . '#comment-' . $commentId);
    }

    public function delete(string|int $id): void {
        $this->requireAuth();
        $this->validateCsrf();

        $id = (int)$id;
        $userId = (int)currentUserId();

        if (!$this->postModel->isOwnedBy($id, $userId) && !hasRole(ROLE_ADMIN)) {
            $this->secLog()->logIdorAttempt('forum_post_delete', $id, $userId);
            setFlash('error', 'Anda tidak memiliki hak untuk menghapus topik ini.');
            $this->redirect('forum');
        }

        $this->postModel->delete($id);
        $this->audit()->log('delete_forum_post', 'forum_post', $id);

        setFlash('success', 'Topik diskusi berhasil dihapus.');
        $this->redirect('forum');
    }

    public function deleteComment(string|int $id): void {
        $this->requireAuth();
        $this->validateCsrf();

        $id = (int)$id;
        $userId = (int)currentUserId();

        $comment = $this->commentModel->find($id);
        if (!$comment) {
            $this->abort(404, 'Komentar tidak ditemukan.');
        }

        if (!$this->commentModel->isOwnedBy($id, $userId) && !hasRole(ROLE_ADMIN)) {
            $this->secLog()->logIdorAttempt('forum_comment_delete', $id, $userId);
            setFlash('error', 'Anda tidak memiliki hak untuk menghapus komentar ini.');
            $this->redirect('forum/' . $comment['post_id']);
        }

        $this->commentModel->delete($id);
        $this->audit()->log('delete_forum_comment', 'forum_comment', $id);

        setFlash('success', 'Komentar berhasil dihapus.');
        $this->redirect('forum/' . $comment['post_id']);
    }
}
