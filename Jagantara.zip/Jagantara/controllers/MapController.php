<?php

class MapController extends Controller {
    private $reportModel;
    private $regionModel;
    private $cleanupLocationModel;

    public function __construct() {
        parent::__construct();
        $this->reportModel = new Report();
        $this->regionModel = new Region();
        $this->cleanupLocationModel = new CleanupLocation();
    }

    public function index() {
        $regions = $this->regionModel->getAll();
        $reports = $this->reportModel->getForMap();
        $cleanupLocations = $this->cleanupLocationModel->getActiveLocations();

        $this->view('home.map', [
            'pageTitle' => 'Peta Sebaran Laporan Lingkungan - ' . APP_NAME,
            'regions'   => $regions,
            'reports'   => $reports,
            'cleanupLocations' => $cleanupLocations,
        ]);
    }

    public function getData() {
        $reports = $this->reportModel->getForMap();

        $data = array_map(function($r) {
            return [
                'id'            => (int)$r['id'],
                'title'         => $r['title'],
                'status'        => $r['status'],
                'status_label'  => statusLabel($r['status']),
                'category'      => $r['category_name'] ?? 'Umum',
                'category_color'=> $r['category_color'] ?? '#1D4533',
                'region'        => $r['region_name'] ?? 'JABODETABEK',
                'location_name' => $r['location_name'] ?? '',
                'lat'           => (float)$r['latitude'],
                'lng'           => (float)$r['longitude'],
                'url'           => url('reports/' . $r['id']),
            ];
        }, $reports);

        $this->json(['success' => true, 'data' => $data]);
    }

    public function getCleanupLocations() {
        $locations = $this->cleanupLocationModel->getActiveLocations();

        $data = array_map(function($location) {
            return [
                'id' => (int)$location['id'],
                'address' => $location['address'],
                'latitude' => (float)$location['latitude'],
                'longitude' => (float)$location['longitude'],
                'status' => $location['status'],
                'statusLabel' => CleanupLocation::getStatusLabel($location['status']),
                'statusColor' => CleanupLocation::getStatusColor($location['status']),
                'description' => $location['description'] ?? '',
                'created_at' => $location['created_at']
            ];
        }, $locations);

        $this->json(['success' => true, 'data' => $data]);
    }
}
