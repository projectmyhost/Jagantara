<div class="container py-8 max-w-4xl">

    <div class="flex items-center gap-2 text-xs text-gray-500 mb-6">
        <a href="<?= url('') ?>" class="hover:text-[#1D4533]">Beranda</a>
        <span>/</span>
        <a href="<?= url('forum') ?>" class="hover:text-[#1D4533]">Forum</a>
        <span>/</span>
        <span class="text-gray-800 font-medium truncate max-w-xs"><?= e($post['title']) ?></span>
    </div>

    <div class="bg-white rounded-2xl border border-gray-200 p-6 sm:p-8 shadow-sm mb-8">
        <div class="flex items-center justify-between gap-4 mb-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-full bg-[#1D4533] text-white flex items-center justify-center text-sm font-bold overflow-hidden">
                    <?php if (!empty($post['avatar_path']) && file_exists(UPLOAD_PATH . '/' . $post['avatar_path'])): ?>
                        <img src="<?= uploadUrl($post['avatar_path']) ?>" class="w-full h-full object-cover" alt="Author">
                    <?php else: ?>
                        <?= strtoupper(substr($post['username'] ?? 'U', 0, 1)) ?>
                    <?php endif; ?>
                </div>
                <div>
                    <div class="text-sm font-bold text-gray-900"><?= e($post['full_name'] ?? $post['username']) ?></div>
                    <div class="text-xs text-gray-400">Diposting <?= formatDate($post['created_at'], 'd M Y H:i') ?></div>
                </div>
            </div>

            <?php if (isLoggedIn() && ($post['author_id'] == currentUserId() || hasRole(ROLE_ADMIN))): ?>
                <form action="<?= url('forum/' . $post['id'] . '/delete') ?>"
                      method="POST"
                      data-confirm="Apakah Anda yakin ingin menghapus topik diskusi ini?"
                      data-confirm-danger
                      data-confirm-title="Hapus Topik Diskusi?"
                      data-confirm-yes="Ya, Hapus"
                      data-confirm-no="Batal">
                    <?= csrfField() ?>
                    <button type="submit" class="text-xs text-red-600 hover:text-red-800 font-medium">
                        Hapus Topik
                    </button>
                </form>
            <?php endif; ?>
        </div>

        <h1 class="text-xl sm:text-2xl font-extrabold text-gray-900 leading-snug mb-4">
            <?= e($post['title']) ?>
        </h1>

        <div class="text-sm text-gray-800 leading-relaxed whitespace-pre-line mb-6">
            <?= e($post['content']) ?>
        </div>

        <div class="pt-4 border-t border-gray-100 flex items-center justify-between text-xs text-gray-500">
            <span>Kategori: <strong><?= e($post['category_name'] ?? 'Umum') ?></strong></span>
            <span><?= (int)($post['view_count'] ?? 0) ?> Kali Dilihat</span>
        </div>
    </div>

    <div class="space-y-6">
        <h2 class="text-lg font-bold text-gray-900 flex items-center gap-2">
            <svg class="w-5 h-5 text-[#1D4533]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
            </svg>
            Komentar & Tanggapan (<?= count($comments) ?>)
        </h2>

        <div class="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm">
            <?php if (isLoggedIn()): ?>
                <form action="<?= url('forum/' . $post['id'] . '/comment') ?>" method="POST">
                    <?= csrfField() ?>
                    <label for="content" class="text-xs font-bold text-gray-700 block mb-2">Tulis Tanggapan Anda</label>
                    <textarea id="content" name="content" rows="3" required class="form-control mb-3 text-xs" placeholder="Tuliskan komentar atau masukan Anda dengan sopan..."></textarea>
                    <div class="flex justify-end">
                        <button type="submit" class="btn btn-primary btn-sm px-5 font-bold">
                            Kirim Komentar
                        </button>
                    </div>
                </form>
            <?php else: ?>
                <div class="text-center py-4">
                    <p class="text-xs text-gray-600 mb-3">Silakan masuk atau daftar terlebih dahulu untuk memberikan komentar.</p>
                    <div class="flex justify-center gap-2">
                        <a href="<?= url('auth/login') ?>" class="btn btn-primary btn-sm text-xs">Masuk</a>
                        <a href="<?= url('auth/register') ?>" class="btn btn-outline btn-sm text-xs">Daftar</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <?php if (!empty($comments)): ?>
            <div class="space-y-3">
                <?php foreach ($comments as $c): ?>
                    <div id="comment-<?= $c['id'] ?>" class="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm">
                        <div class="flex items-center justify-between mb-2">
                            <div class="flex items-center gap-2">
                                <div class="w-7 h-7 rounded-full bg-[#1D4533] text-white flex items-center justify-center text-xs font-bold overflow-hidden">
                                    <?php if (!empty($c['avatar_path']) && file_exists(UPLOAD_PATH . '/' . $c['avatar_path'])): ?>
                                        <img src="<?= uploadUrl($c['avatar_path']) ?>" class="w-full h-full object-cover" alt="Avatar">
                                    <?php else: ?>
                                        <?= strtoupper(substr($c['username'] ?? 'U', 0, 1)) ?>
                                    <?php endif; ?>
                                </div>
                                <span class="text-xs font-bold text-gray-900"><?= e($c['full_name'] ?? $c['username']) ?></span>
                                <span class="text-[11px] text-gray-400">&bull; <?= formatDate($c['created_at'], 'relative') ?></span>
                            </div>

                            <?php if (isLoggedIn() && ($c['author_id'] == currentUserId() || hasRole(ROLE_ADMIN))): ?>
                                <form action="<?= url('forum/comment/' . $c['id'] . '/delete') ?>"
                                      method="POST"
                                      data-confirm="Apakah Anda yakin ingin menghapus komentar ini?"
                                      data-confirm-danger
                                      data-confirm-title="Hapus Komentar?"
                                      data-confirm-yes="Ya, Hapus"
                                      data-confirm-no="Batal">
                                    <?= csrfField() ?>
                                    <button type="submit" class="text-[11px] text-red-500 hover:text-red-700">
                                        Hapus
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>

                        <div class="text-xs text-gray-700 leading-relaxed whitespace-pre-line pl-9">
                            <?= e($c['content']) ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-xs text-gray-500 text-center py-4">Belum ada komentar untuk topik ini.</p>
        <?php endif; ?>

    </div>

</div>
