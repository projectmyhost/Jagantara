<div class="page-header">
    <div class="container">
        <h1>Forum Diskusi Lingkungan</h1>
        <p>Wadah diskusi, aspirasi, dan koordinasi aksi lingkungan bagi seluruh warga JABODETABEK.</p>
    </div>
</div>

<div class="container py-8">

    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
            <h2 class="text-lg font-bold text-gray-900">Diskusi Warga</h2>
            <p class="text-xs text-gray-500">Berbagi pengalaman, tips pemilahan sampah, dan rencana aksi bersama.</p>
        </div>

        <div>
            <?php if (isLoggedIn()): ?>
                <a href="<?= url('forum/create') ?>" class="btn btn-primary btn-sm">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                    </svg>
                    Buat Topik Baru
                </a>
            <?php else: ?>
                <button type="button" onclick="openGuestAuthModal('forum')" class="btn btn-primary btn-sm">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                    </svg>
                    Buat Topik Baru
                </button>
            <?php endif; ?>
        </div>
    </div>

    <div class="category-pills-scroll mb-6">
        <a href="<?= url('forum') ?>" class="category-pill <?= empty($filters['category_id']) ? 'active' : '' ?>">
            Semua Topik
        </a>
        <?php foreach ($categories as $cat): ?>
            <a href="<?= url('forum?category=' . $cat['id']) ?>" class="category-pill <?= ($filters['category_id'] ?? 0) == $cat['id'] ? 'active' : '' ?>">
                <?= e($cat['name']) ?>
            </a>
        <?php endforeach; ?>
    </div>

    <?php if (!empty($posts)): ?>
        <div class="space-y-4 mb-8">
            <?php foreach ($posts as $post): ?>
                <div class="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm hover:shadow-md transition">
                    <div class="flex items-start gap-4">

                        <div class="w-10 h-10 rounded-full bg-[#1D4533] text-white flex items-center justify-center text-sm font-bold flex-shrink-0 overflow-hidden">
                            <?php if (!empty($post['avatar_path']) && file_exists(UPLOAD_PATH . '/' . $post['avatar_path'])): ?>
                                <img src="<?= uploadUrl($post['avatar_path']) ?>" class="w-full h-full object-cover" alt="Author">
                            <?php else: ?>
                                <?= strtoupper(substr($post['username'] ?? 'U', 0, 1)) ?>
                            <?php endif; ?>
                        </div>

                        <div class="flex-1 min-w-0">
                            <div class="flex flex-wrap items-center gap-2 mb-1 text-xs text-gray-500">
                                <span class="font-bold text-gray-900"><?= e($post['full_name'] ?? $post['username']) ?></span>
                                <span>&bull;</span>
                                <?php if (!empty($post['category_name'])): ?>
                                    <span class="bg-[#F7EAE0] text-[#5E3122] px-2 py-0.5 rounded font-semibold">
                                        <?= e($post['category_name']) ?>
                                    </span>
                                    <span>&bull;</span>
                                <?php endif; ?>
                                <span><?= formatDate($post['created_at'], 'relative') ?></span>
                            </div>

                            <h3 class="text-base font-bold text-gray-900 mb-1">
                                <a href="<?= url('forum/' . $post['id']) ?>" class="hover:text-[#1D4533]">
                                    <?= e($post['title']) ?>
                                </a>
                            </h3>

                            <p class="text-xs text-gray-600 line-clamp-2 leading-relaxed mb-3">
                                <?= e(truncate($post['content'], 180)) ?>
                            </p>

                            <div class="flex items-center gap-4 text-xs text-gray-500 font-medium">
                                <span class="flex items-center gap-1">
                                    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
                                    </svg>
                                    <?= (int)($post['comment_count'] ?? 0) ?> Komentar
                                </span>
                                <span class="flex items-center gap-1">
                                    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                    </svg>
                                    <?= (int)($post['view_count'] ?? 0) ?> Dilihat
                                </span>
                            </div>
                        </div>

                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if (($pagination['total_pages'] ?? 1) > 1): ?>
            <div class="flex items-center justify-center gap-2 pt-4">
                <?php if ($pagination['has_prev']): ?>
                    <a href="<?= url('forum?page=' . $pagination['prev_page'] . '&category=' . ($filters['category_id'] ?? '')) ?>" class="btn btn-outline btn-sm">
                        Sebelumnya
                    </a>
                <?php endif; ?>
                <span class="text-xs text-gray-600 font-medium px-2">
                    Halaman <?= $pagination['current_page'] ?> dari <?= $pagination['total_pages'] ?>
                </span>
                <?php if ($pagination['has_next']): ?>
                    <a href="<?= url('forum?page=' . $pagination['next_page'] . '&category=' . ($filters['category_id'] ?? '')) ?>" class="btn btn-outline btn-sm">
                        Selanjutnya
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <div class="empty-state bg-white rounded-2xl border border-gray-200 p-12">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
            </svg>
            <h3 class="text-base font-bold text-gray-800 mb-1">Belum Ada Topik Diskusi</h3>
            <p class="text-xs text-gray-500 max-w-sm mx-auto mb-4">Mulai diskusi pertama Anda mengenai isu lingkungan di wilayah Anda.</p>
            <?php if (isLoggedIn()): ?>
                <a href="<?= url('forum/create') ?>" class="btn btn-primary btn-sm">Buat Topik Pertama</a>
            <?php else: ?>
                <button type="button" onclick="openGuestAuthModal('forum')" class="btn btn-primary btn-sm">Buat Topik Pertama</button>
            <?php endif; ?>
        </div>
    <?php endif; ?>

</div>
