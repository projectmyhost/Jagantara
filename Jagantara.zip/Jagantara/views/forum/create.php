<div class="page-header">
    <div class="container">
        <h1>Buat Topik Diskusi Baru</h1>
        <p>Mulai percakapan mengenai permasalahan atau inisiatif lingkungan di wilayah Anda.</p>
    </div>
</div>

<div class="container py-8 max-w-2xl">

    <div class="bg-white rounded-2xl border border-gray-200 p-6 sm:p-8 shadow-sm">
        <form action="<?= url('forum/store') ?>" method="POST">
            <?= csrfField() ?>

            <div class="space-y-5">

                <div class="form-group mb-0">
                    <label for="title" class="form-label">Judul Topik Diskusi <span class="required">*</span></label>
                    <input type="text" id="title" name="title" required
                           value="<?= e($values['title'] ?? '') ?>"
                           class="form-control <?= !empty($errors['title']) ? 'error' : '' ?>"
                           placeholder="Contoh: Ide Pengelolaan Sampah Organik Rumah Tangga">
                    <?php if (!empty($errors['title'])): ?>
                        <div class="form-error"><?= e($errors['title']) ?></div>
                    <?php endif; ?>
                </div>

                <div class="form-group mb-0">
                    <label for="category_id" class="form-label">Kategori</label>
                    <select id="category_id" name="category_id" class="form-control">
                        <option value="">-- Pilih Kategori (Opsional) --</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>" <?= ($values['category_id'] ?? '') == $cat['id'] ? 'selected' : '' ?>>
                                <?= e($cat['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group mb-0">
                    <label for="content" class="form-label">Isi Percakapan & Diskusi <span class="required">*</span></label>
                    <textarea id="content" name="content" rows="6" required
                              class="form-control <?= !empty($errors['content']) ? 'error' : '' ?>"
                              placeholder="Tuliskan latar belakang masalah, saran solusi, atau ajakan kepada warga secara sopan dan jelas"><?= e($values['content'] ?? '') ?></textarea>
                    <?php if (!empty($errors['content'])): ?>
                        <div class="form-error"><?= e($errors['content']) ?></div>
                    <?php endif; ?>
                </div>

                <div class="pt-3 flex items-center justify-end gap-3">
                    <a href="<?= url('forum') ?>" class="btn btn-outline py-2.5 px-5">
                        Batal
                    </a>
                    <button type="submit" class="btn btn-primary py-2.5 px-6 font-bold shadow-md">
                        Terbitkan Topik
                    </button>
                </div>

            </div>
        </form>
    </div>

</div>
