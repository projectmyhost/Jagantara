<div class="page-header">
    <div class="container">
        <h1>Edit Profil Pengguna</h1>
        <p>Perbarui informasi profil dan data pribadi Anda.</p>
    </div>
</div>

<div class="container py-8">
    <div class="max-w-2xl mx-auto">

        <div class="bg-white rounded-2xl border border-gray-200 p-6 sm:p-8 shadow-sm">
            <form action="<?= url('profile/update') ?>" method="POST" enctype="multipart/form-data">
                <?= csrfField() ?>

                <div class="space-y-6">

                    <div>
                        <label class="form-label">Foto Profil</label>
                        <div class="flex items-center gap-4">
                            <div class="w-16 h-16 rounded-full bg-[#1D4533] text-white flex items-center justify-center text-xl font-bold overflow-hidden border-2 border-gray-200 flex-shrink-0">
                                <?php if (!empty($user['avatar_path']) && file_exists(UPLOAD_PATH . '/' . $user['avatar_path'])): ?>
                                    <img id="avatar-preview" src="<?= uploadUrl($user['avatar_path']) ?>" class="w-full h-full object-cover" alt="Avatar">
                                <?php else: ?>
                                    <span id="avatar-placeholder"><?= strtoupper(substr($user['username'] ?? 'U', 0, 1)) ?></span>
                                <?php endif; ?>
                            </div>
                            <div>
                                <input type="file" name="avatar" id="avatar" accept="image/jpeg,image/png,image/webp" class="text-xs text-gray-600 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-emerald-50 file:text-[#1D4533] hover:file:bg-emerald-100" onchange="previewAvatar(this)">
                                <p class="text-[11px] text-gray-400 mt-1">Format: JPG, PNG, WebP. Maksimal 5MB.</p>
                            </div>
                        </div>
                    </div>

                    <div class="form-group mb-0">
                        <label for="email_disabled" class="form-label">Alamat Email</label>
                        <input type="text" id="email_disabled" value="<?= e($user['email']) ?>" disabled
                               class="form-control bg-gray-100 text-gray-500 cursor-not-allowed">
                        <span class="text-[11px] text-gray-400 mt-1 block">Email tidak dapat diubah melalui pengaturan profil.</span>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="form-group mb-0">
                            <label for="username" class="form-label">Username <span class="required">*</span></label>
                            <input type="text" id="username" name="username" required
                                   value="<?= e($user['username'] ?? '') ?>"
                                   class="form-control" placeholder="username">
                        </div>

                        <div class="form-group mb-0">
                            <label for="full_name" class="form-label">Nama Lengkap <span class="required">*</span></label>
                            <input type="text" id="full_name" name="full_name" required
                                   value="<?= e($user['full_name'] ?? '') ?>"
                                   class="form-control" placeholder="Nama Lengkap">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="form-group mb-0">
                            <label for="phone" class="form-label">Nomor Handphone</label>
                            <input type="text" id="phone" name="phone"
                                   value="<?= e($user['phone'] ?? '') ?>"
                                   class="form-control" placeholder="Contoh: 08123456789">
                        </div>

                        <div class="form-group mb-0">
                            <label for="region_id" class="form-label">Wilayah (JABODETABEK)</label>
                            <select id="region_id" name="region_id" class="form-control">
                                <option value="">-- Pilih Wilayah --</option>
                                <?php foreach ($regions as $r): ?>
                                    <option value="<?= $r['id'] ?>" <?= ($user['region_id'] ?? '') == $r['id'] ? 'selected' : '' ?>>
                                        <?= e($r['name']) ?> <?= !empty($r['parent_name']) ? '(' . e($r['parent_name']) . ')' : '' ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="form-group mb-0">
                            <label for="birth_date" class="form-label">Tanggal Lahir</label>
                            <input type="date" id="birth_date" name="birth_date"
                                   value="<?= e($user['birth_date'] ?? '') ?>"
                                   class="form-control">
                        </div>

                        <div class="form-group mb-0">
                            <label for="gender" class="form-label">Jenis Kelamin</label>
                            <select id="gender" name="gender" class="form-control">
                                <option value="">-- Pilih Jenis Kelamin --</option>
                                <option value="male" <?= ($user['gender'] ?? '') === 'male' ? 'selected' : '' ?>>Laki-laki</option>
                                <option value="female" <?= ($user['gender'] ?? '') === 'female' ? 'selected' : '' ?>>Perempuan</option>
                                <option value="other" <?= ($user['gender'] ?? '') === 'other' ? 'selected' : '' ?>>Lainnya</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group mb-0">
                        <label for="address" class="form-label">Alamat Lengkap</label>
                        <textarea id="address" name="address" rows="3"
                                  class="form-control"
                                  placeholder="Alamat domisili tempat tinggal"><?= e($user['address'] ?? '') ?></textarea>
                    </div>

                    <div class="pt-4 flex items-center justify-end gap-3 border-t border-gray-100">
                        <a href="<?= url('profile') ?>" class="btn btn-outline py-2.5 px-5">
                            Batal
                        </a>
                        <button type="submit" class="btn btn-primary py-2.5 px-6 font-bold shadow-md">
                            Simpan Perubahan
                        </button>
                    </div>

                </div>
            </form>
        </div>

    </div>
</div>

<script>
function previewAvatar(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            let preview = document.getElementById('avatar-preview');
            const placeholder = document.getElementById('avatar-placeholder');
            if (!preview) {
                if (placeholder) placeholder.remove();
                preview = document.createElement('img');
                preview.id = 'avatar-preview';
                preview.className = 'w-full h-full object-cover';
                input.parentElement.previousElementSibling.appendChild(preview);
            }
            preview.src = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>
