<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pemeliharaan Sistem — <?= e(setting('site_name', APP_NAME)) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #0b1510;
            color: #e5e7eb;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px 16px;
            position: relative;
            overflow-x: hidden;
        }

        .bg-ambient {
            position: fixed;
            inset: 0;
            background:
                radial-gradient(circle at 50% 20%, rgba(29, 69, 51, 0.45) 0%, transparent 60%),
                radial-gradient(circle at 80% 80%, rgba(217, 119, 6, 0.08) 0%, transparent 40%),
                radial-gradient(circle at 20% 80%, rgba(16, 185, 129, 0.08) 0%, transparent 40%);
            pointer-events: none;
            z-index: 0;
        }

        .bg-grid {
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(to right, rgba(255, 255, 255, 0.03) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            pointer-events: none;
            z-index: 0;
            mask-image: radial-gradient(circle at 50% 50%, black 40%, transparent 80%);
            -webkit-mask-image: radial-gradient(circle at 50% 50%, black 40%, transparent 80%);
        }

        .container {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 520px;
        }

        .card {
            background: rgba(18, 34, 26, 0.85);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-top: 1px solid rgba(52, 211, 153, 0.35);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border-radius: 28px;
            padding: 40px 32px;
            box-shadow:
                0 25px 50px -12px rgba(0, 0, 0, 0.6),
                0 0 40px rgba(16, 185, 129, 0.05);
            text-align: center;
        }

        .brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 24px;
        }

        .brand-icon {
            width: 36px;
            height: 36px;
            background: rgba(16, 185, 129, 0.15);
            border: 1px solid rgba(16, 185, 129, 0.3);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #34d399;
        }

        .brand-name {
            font-size: 15px;
            font-weight: 800;
            letter-spacing: 0.5px;
            color: #ffffff;
            text-transform: uppercase;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 14px;
            background: rgba(245, 158, 11, 0.12);
            border: 1px solid rgba(245, 158, 11, 0.35);
            border-radius: 9999px;
            font-size: 12px;
            font-weight: 700;
            color: #fbbf24;
            letter-spacing: 0.3px;
            margin-bottom: 20px;
        }

        .pulse-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background-color: #f59e0b;
            box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.7);
            animation: pulse-glow 2s infinite cubic-bezier(0.66, 0, 0, 1);
        }

        @keyframes pulse-glow {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.7); }
            70% { transform: scale(1); box-shadow: 0 0 0 8px rgba(245, 158, 11, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(245, 158, 11, 0); }
        }

        h1 {
            font-size: 24px;
            font-weight: 800;
            color: #ffffff;
            line-height: 1.3;
            letter-spacing: -0.5px;
            margin-bottom: 12px;
        }

        p.description {
            font-size: 14px;
            color: #9ca3af;
            line-height: 1.6;
            margin-bottom: 28px;
        }

        .info-box {
            background: rgba(11, 21, 16, 0.65);
            border: 1px solid rgba(255, 255, 255, 0.06);
            border-radius: 18px;
            padding: 16px 20px;
            margin-bottom: 28px;
            text-align: left;
        }

        .info-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 13px;
            padding: 6px 0;
        }

        .info-row:not(:last-child) {
            border-bottom: 1px solid rgba(255, 255, 255, 0.04);
        }

        .info-label {
            color: #6b7280;
            font-weight: 500;
        }

        .info-value {
            color: #d1d5db;
            font-weight: 600;
        }

        .info-value a {
            color: #34d399;
            text-decoration: none;
            transition: color 0.15s ease;
        }

        .info-value a:hover {
            color: #6ee7b7;
            text-decoration: underline;
        }

        .btn-refresh {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            width: 100%;
            padding: 14px 24px;
            background: #1D4533;
            color: #ffffff;
            border: 1px solid rgba(52, 211, 153, 0.3);
            border-radius: 16px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        .btn-refresh:hover {
            background: #14301F;
            border-color: #34d399;
            transform: translateY(-1px);
        }

        .btn-refresh:active {
            transform: translateY(0);
        }

        .footer-note {
            margin-top: 24px;
            font-size: 11px;
            color: #4b5563;
        }

        @media (max-width: 480px) {
            .card {
                padding: 32px 20px;
                border-radius: 24px;
            }
            h1 {
                font-size: 21px;
            }
        }
    </style>
</head>
<body>
    <div class="bg-ambient"></div>
    <div class="bg-grid"></div>

    <main class="container">
        <div class="card">

            <div class="brand">
                <div class="brand-icon">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <span class="brand-name"><?= e(setting('site_name', APP_NAME)) ?></span>
            </div>

            <div>
                <div class="status-badge">
                    <span class="pulse-dot"></span>
                    <span>Mode Pemeliharaan Sistem</span>
                </div>
            </div>

            <h1>Platform Sedang Ditingkatkan</h1>
            <p class="description">
                Kami sedang melakukan optimalisasi performa dan pemeliharaan server berkala. Layanan pelaporan dan aksi lingkungan akan segera kembali aktif.
            </p>

            <div class="info-box">
                <div class="info-row">
                    <span class="info-label">Status Akses</span>
                    <span class="info-value" style="color: #fbbf24;">Ditutup Sementara</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Bantuan / Email</span>
                    <span class="info-value">
                        <a href="mailto:<?= e(setting('site_contact_email', 'info@jagantara.id')) ?>">
                            <?= e(setting('site_contact_email', 'info@jagantara.id')) ?>
                        </a>
                    </span>
                </div>
                <?php if (!empty(setting('site_contact_phone'))): ?>
                    <div class="info-row">
                        <span class="info-label">Kontak Layanan</span>
                        <span class="info-value"><?= e(setting('site_contact_phone')) ?></span>
                    </div>
                <?php endif; ?>
            </div>

            <button type="button" class="btn-refresh" onclick="window.location.reload()">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                </svg>
                Muat Ulang Halaman
            </button>

            <div class="footer-note">
                &copy; <?= date('Y') ?> <?= e(setting('site_name', APP_NAME)) ?>. Seluruh hak cipta dilindungi.
            </div>

        </div>
    </main>
</body>
</html>
