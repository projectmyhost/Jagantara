<div class="page-header">
    <div class="container">
        <h1>Formulir Pendaftaran Anggota</h1>
        <p>Bergabung dengan <strong><?= e($organizer['name']) ?></strong> untuk aksi lingkungan nyata.</p>
    </div>
</div>

<div class="container py-8">
    <div class="max-w-2xl mx-auto">

        <?php if ($isComplete): ?>
            <div class="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 mb-6 text-emerald-900 text-xs sm:text-sm">
                <div class="flex items-start gap-3">
                    <svg class="w-5 h-5 text-emerald-700 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <div>
                        <span class="font-bold block text-emerald-950 mb-0.5">Profil Anda Lengkap</span>
                        Data formulir di bawah ini otomatis terisi dari data profil Anda yang sudah tersimpan. Perubahan data hanya dapat dilakukan melalui menu <a href="<?= url('profile/edit') ?>" class="underline font-semibold">Pengaturan Profil</a>.
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-6 text-amber-900 text-xs sm:text-sm">
                <div class="flex items-start gap-3">
                    <svg class="w-5 h-5 text-amber-700 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                    </svg>
                    <div>
                        <span class="font-bold block text-amber-950 mb-0.5">Profil Belum Lengkap</span>
                        Silakan lengkapi data pada formulir pendaftaran ini. Data yang Anda masukkan hanya digunakan untuk proses verifikasi pendaftaran organizer dan tidak otomatis menjadi profil permanen Anda.
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="bg-white rounded-2xl border border-gray-200 p-6 sm:p-8 shadow-sm">
            <form action="<?= url('organizers/join/' . $organizer['id']) ?>" method="POST" enctype="multipart/form-data">
                <?= csrfField() ?>

                <div class="space-y-5">

                    <div class="form-group mb-0">
                        <label for="full_name" class="form-label">Nama Lengkap <span class="required">*</span></label>
                        <input type="text" id="full_name" name="full_name" required
                               value="<?= e($userProfile['full_name'] ?? '') ?>"
                               <?= $isComplete ? 'readonly class="form-control bg-gray-50 text-gray-700 cursor-not-allowed"' : 'class="form-control"' ?>
                               placeholder="Nama lengkap sesuai identitas">
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="form-group mb-0">
                            <label for="phone" class="form-label">Nomor Handphone (WhatsApp) <span class="required">*</span></label>
                            <input type="text" id="phone" name="phone" required
                                   value="<?= e($userProfile['phone'] ?? '') ?>"
                                   <?= $isComplete ? 'readonly class="form-control bg-gray-50 text-gray-700 cursor-not-allowed"' : 'class="form-control"' ?>
                                   placeholder="Contoh: 08123456789">
                        </div>

                        <div class="form-group mb-0">
                            <label for="region_id" class="form-label">Wilayah Tempat Tinggal <span class="required">*</span></label>
                            <?php if ($isComplete): ?>
                                <input type="hidden" name="region_id" value="<?= (int)($userProfile['region_id'] ?? 0) ?>">
                                <input type="text" readonly value="<?= e($userProfile['region_name'] ?? '-') ?>" class="form-control bg-gray-50 text-gray-700 cursor-not-allowed">
                            <?php else: ?>
                                <select id="region_id" name="region_id" required class="form-control">
                                    <option value="">-- Pilih Wilayah --</option>
                                    <?php foreach ($regions as $r): ?>
                                        <option value="<?= $r['id'] ?>" <?= ($userProfile['region_id'] ?? '') == $r['id'] ? 'selected' : '' ?>>
                                            <?= e($r['name']) ?> <?= !empty($r['parent_name']) ? '(' . e($r['parent_name']) . ')' : '' ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="form-group mb-0">
                            <label for="birth_date" class="form-label">Tanggal Lahir <span class="required">*</span></label>
                            <input type="date" id="birth_date" name="birth_date" required
                                   value="<?= e($userProfile['birth_date'] ?? '') ?>"
                                   <?= $isComplete ? 'readonly class="form-control bg-gray-50 text-gray-700 cursor-not-allowed"' : 'class="form-control"' ?>>
                        </div>

                        <div class="form-group mb-0">
                            <label for="gender" class="form-label">Jenis Kelamin <span class="required">*</span></label>
                            <?php if ($isComplete): ?>
                                <input type="hidden" name="gender" value="<?= e($userProfile['gender'] ?? '') ?>">
                                <input type="text" readonly value="<?= ($userProfile['gender'] ?? '') === 'male' ? 'Laki-laki' : 'Perempuan' ?>" class="form-control bg-gray-50 text-gray-700 cursor-not-allowed">
                            <?php else: ?>
                                <select id="gender" name="gender" required class="form-control">
                                    <option value="">-- Pilih Jenis Kelamin --</option>
                                    <option value="male" <?= ($userProfile['gender'] ?? '') === 'male' ? 'selected' : '' ?>>Laki-laki</option>
                                    <option value="female" <?= ($userProfile['gender'] ?? '') === 'female' ? 'selected' : '' ?>>Perempuan</option>
                                    <option value="other" <?= ($userProfile['gender'] ?? '') === 'other' ? 'selected' : '' ?>>Lainnya</option>
                                </select>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group mb-0">
                        <label for="address" class="form-label">Alamat Lengkap <span class="required">*</span></label>
                        <textarea id="address" name="address" rows="2" required
                                  <?= $isComplete ? 'readonly class="form-control bg-gray-50 text-gray-700 cursor-not-allowed"' : 'class="form-control"' ?>
                                  placeholder="Alamat domisili Anda"><?= e($userProfile['address'] ?? '') ?></textarea>
                    </div>

                    <hr class="my-4 border-gray-100">

                    <div class="bg-gray-50 p-4 rounded-xl border border-gray-200 space-y-4">
                        <div class="text-xs font-bold text-gray-800 uppercase tracking-wider">
                            Dokumen Verifikasi (Hanya Dilihat Admin)
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label for="face_photo" class="text-xs font-semibold text-gray-700 block mb-1">Foto Wajah / Pas Foto</label>
                                <input type="file" id="face_photo" name="face_photo" accept="image/jpeg,image/png,image/webp" class="text-xs text-gray-600 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-emerald-100 file:text-[#1D4533]">
                                <span class="text-[10px] text-gray-400 block mt-1">Format: JPG, PNG. Maks 5MB.</span>
                            </div>

                            <div>
                                <label for="ktp" class="text-xs font-semibold text-gray-700 block mb-1">Foto KTP / Identitas</label>
                                <input type="file" id="ktp" name="ktp" accept="image/jpeg,image/png,image/webp" class="text-xs text-gray-600 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-emerald-100 file:text-[#1D4533]">
                                <span class="text-[10px] text-gray-400 block mt-1">Data identitas aman & terenkripsi.</span>
                            </div>
                        </div>

                        <p class="text-[11px] text-gray-500 italic">
                            Jaminan Privasi: Foto identitas dan KTP tidak akan pernah ditampilkan secara publik. Hanya admin berwenang yang dapat memeriksa dokumen untuk memverifikasi keaslian anggota.
                        </p>
                    </div>

                    <div class="form-group mb-0">
                        <label for="motivation" class="form-label">Motivasi & Pengalaman Singkat (Opsional)</label>
                        <textarea id="motivation" name="motivation" rows="3" class="form-control"
                                  placeholder="Ceritakan alasan Anda ingin bergabung dan pengalaman aksi lingkungan yang pernah diikuti"></textarea>
                    </div>

                    <div class="pt-3 flex flex-col sm:flex-row gap-3">
                        <button type="submit" class="btn btn-primary py-3 flex-1 font-bold shadow-md">
                            Kirim Pendaftaran
                        </button>
                        <a href="<?= url('organizers/' . $organizer['id']) ?>" class="btn btn-outline py-3 text-center sm:w-32">
                            Batal
                        </a>
                    </div>

                </div>
            </form>
        </div>

    </div>
</div>
