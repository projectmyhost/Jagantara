<div class="space-y-6">

    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h2 class="text-base font-bold text-gray-900">Security Events & Incident Logs</h2>
            <p class="text-xs text-gray-500">Pencatatan insiden keamanan, percobaan brute-force, deteksi IDOR, dan pelanggaran rate limit.</p>
        </div>
        <a href="<?= url('admin/audit-logs') ?>" class="btn btn-outline btn-sm">
            Kembali ke Audit Logs
        </a>
    </div>

    <?php if (!empty($logs)): ?>
        <div class="table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Waktu</th>
                        <th>Tipe Event Keamanan</th>
                        <th>IP Address</th>
                        <th>User Terkait</th>
                        <th>User Agent</th>
                        <th>Keterangan / Context</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $l): ?>
                        <tr>
                            <td class="font-bold text-gray-500 text-xs w-12 text-center">#<?= $l['id'] ?></td>
                            <td class="text-xs text-gray-500 whitespace-nowrap">
                                <?= formatDate($l['created_at'], 'd M Y H:i:s') ?>
                            </td>
                            <td>
                                <span class="badge badge-rejected uppercase text-[10px] font-bold">
                                    <?= e($l['event_type']) ?>
                                </span>
                            </td>
                            <td class="text-xs font-mono text-gray-800 font-semibold"><?= e($l['ip_address'] ?? '-') ?></td>
                            <td class="text-xs text-gray-700">
                                <?= !empty($l['email']) ? e($l['email']) : '<span class="text-gray-400">Anonim / Guest</span>' ?>
                            </td>
                            <td class="text-[11px] text-gray-400 max-w-xs truncate font-mono">
                                <?= e($l['user_agent'] ?? '-') ?>
                            </td>
                            <td class="text-xs text-gray-600 font-mono max-w-xs truncate">
                                <?= e($l['context'] ?? '-') ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if (($pagination['total_pages'] ?? 1) > 1): ?>
            <div class="flex items-center justify-center gap-2 pt-6">
                <?php if ($pagination['has_prev']): ?>
                    <a href="<?= url('admin/security-logs?page=' . ($pagination['current_page'] - 1)) ?>" class="btn btn-outline btn-sm">
                        Sebelumnya
                    </a>
                <?php endif; ?>
                <span class="text-xs text-gray-600 font-medium px-2">
                    Halaman <?= $pagination['current_page'] ?> dari <?= $pagination['total_pages'] ?>
                </span>
                <?php if ($pagination['has_next']): ?>
                    <a href="<?= url('admin/security-logs?page=' . ($pagination['current_page'] + 1)) ?>" class="btn btn-outline btn-sm">
                        Selanjutnya
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <div class="empty-state bg-white rounded-2xl border border-gray-200 p-12">
            <h3 class="text-base font-bold text-gray-800 mb-1">Tidak Ada Insiden Keamanan</h3>
            <p class="text-xs text-gray-500">Sistem berjalan normal dan aman.</p>
        </div>
    <?php endif; ?>

</div>
