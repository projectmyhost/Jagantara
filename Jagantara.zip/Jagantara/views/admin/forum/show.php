<div class="space-y-6 max-w-4xl">

    <div class="flex items-center justify-between">
        <div>
            <h2 class="text-base font-bold text-gray-900">Moderasi Topik: <?= e($post['title']) ?></h2>
            <p class="text-xs text-gray-500">Penulis: <?= e($post['full_name'] ?? $post['username']) ?> &bull; <?= formatDate($post['created_at'], 'd M Y H:i') ?></p>
        </div>
        <div class="flex items-center gap-2">
            <form action="<?= url('admin/forum/' . $post['id'] . '/delete') ?>"
                  method="POST"
                  data-confirm="Apakah Anda yakin ingin menghapus topik diskusi ini?"
                  data-confirm-danger
                  data-confirm-title="Hapus Topik Diskusi?"
                  data-confirm-yes="Ya, Hapus"
                  data-confirm-no="Batal">
                <?= csrfField() ?>
                <button type="submit" class="btn btn-danger btn-sm text-xs">Hapus Topik</button>
            </form>
            <a href="<?= url('admin/forum') ?>" class="btn btn-outline btn-sm text-xs">Kembali</a>
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
        <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Isi Topik:</h3>
        <div class="text-sm text-gray-800 leading-relaxed whitespace-pre-line bg-gray-50 p-4 rounded-xl border border-gray-100 mb-4">
            <?= e($post['content']) ?>
        </div>
        <div class="text-xs text-gray-500">
            Kategori: <strong><?= e($post['category_name'] ?? 'Umum') ?></strong> &bull; Dilihat: <strong><?= (int)$post['view_count'] ?> kali</strong>
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm space-y-4">
        <h3 class="text-base font-bold text-gray-900">Komentar Terdaftar (<?= count($comments) ?>)</h3>

        <?php if (!empty($comments)): ?>
            <div class="space-y-3">
                <?php foreach ($comments as $c): ?>
                    <div class="p-4 rounded-xl bg-gray-50 border border-gray-100 flex items-start justify-between gap-4">
                        <div class="flex-1">
                            <div class="flex items-center gap-2 mb-1">
                                <span class="font-bold text-xs text-gray-900"><?= e($c['full_name'] ?? $c['username']) ?></span>
                                <span class="text-[11px] text-gray-400">&bull; <?= formatDate($c['created_at'], 'd M Y H:i') ?></span>
                            </div>
                            <div class="text-xs text-gray-700 leading-relaxed whitespace-pre-line">
                                <?= e($c['content']) ?>
                            </div>
                        </div>

                        <form action="<?= url('admin/forum/comment/' . $c['id'] . '/delete') ?>"
                              method="POST"
                              data-confirm="Apakah Anda yakin ingin menghapus komentar ini?"
                              data-confirm-danger
                              data-confirm-title="Hapus Komentar?"
                              data-confirm-yes="Ya, Hapus"
                              data-confirm-no="Batal">
                            <?= csrfField() ?>
                            <button type="submit" class="btn btn-danger btn-sm text-xs py-1 px-2.5">
                                Hapus Komentar
                            </button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-xs text-gray-500">Belum ada komentar pada topik ini.</p>
        <?php endif; ?>
    </div>

</div>
