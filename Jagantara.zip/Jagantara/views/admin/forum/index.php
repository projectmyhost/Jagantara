<div class="space-y-6">

    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h2 class="text-base font-bold text-gray-900">Moderasi Forum Diskusi</h2>
            <p class="text-xs text-gray-500">Pantau diskusi warga, kelola komentar, dan hapus konten yang melanggar aturan.</p>
        </div>
    </div>

    <?php if (!empty($posts)): ?>
        <div class="table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Judul Topik</th>
                        <th>Penulis</th>
                        <th>Kategori</th>
                        <th>Komentar</th>
                        <th>Dilihat</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($posts as $p): ?>
                        <tr>
                            <td class="font-bold text-gray-500 text-xs w-12 text-center">#<?= $p['id'] ?></td>
                            <td>
                                <a href="<?= url('admin/forum/' . $p['id']) ?>" class="font-bold text-gray-900 text-sm hover:text-[#1D4533]">
                                    <?= e($p['title']) ?>
                                </a>
                            </td>
                            <td class="text-xs text-gray-600">
                                <div class="font-medium text-gray-900"><?= e($p['full_name'] ?? $p['username']) ?></div>
                                <div class="text-[11px] text-gray-400"><?= e($p['email'] ?? '') ?></div>
                            </td>
                            <td class="text-xs text-gray-600">
                                <?= e($p['category_name'] ?? 'Umum') ?>
                            </td>
                            <td class="text-xs font-bold text-gray-700"><?= (int)$p['comment_count'] ?></td>
                            <td class="text-xs text-gray-500"><?= (int)$p['view_count'] ?></td>
                            <td class="text-xs text-gray-500 whitespace-nowrap"><?= formatDate($p['created_at'], 'd M Y') ?></td>
                            <td>
                                <div class="flex items-center gap-2">
                                    <a href="<?= url('admin/forum/' . $p['id']) ?>" class="btn btn-outline btn-sm text-xs py-1 px-2.5">
                                        Periksa
                                    </a>
                                    <form action="<?= url('admin/forum/' . $p['id'] . '/delete') ?>"
                                          method="POST"
                                          data-confirm="Apakah Anda yakin ingin menghapus topik diskusi ini beserta seluruh komentarnya?"
                                          data-confirm-danger
                                          data-confirm-title="Hapus Topik Diskusi?"
                                          data-confirm-yes="Ya, Hapus"
                                          data-confirm-no="Batal">
                                        <?= csrfField() ?>
                                        <button type="submit" class="btn btn-danger btn-sm text-xs py-1 px-2.5">
                                            Hapus
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state bg-white rounded-2xl border border-gray-200 p-12">
            <h3 class="text-base font-bold text-gray-800 mb-1">Belum Ada Topik Forum</h3>
            <p class="text-xs text-gray-500">Belum ada topik diskusi yang dibuat oleh masyarakat.</p>
        </div>
    <?php endif; ?>

</div>
