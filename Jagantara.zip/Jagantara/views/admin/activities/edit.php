<div class="max-w-2xl">
    <div class="bg-white rounded-2xl border border-gray-200 p-6 sm:p-8 shadow-sm">

        <div class="mb-6 pb-4 border-b border-gray-100">
            <h2 class="text-base font-bold text-gray-900">Edit Kegiatan #<?= $activity['id'] ?></h2>
            <p class="text-xs text-gray-500">Perbarui jadwal, lokasi, atau status kegiatan.</p>
        </div>

        <form action="<?= url('admin/activities/' . $activity['id'] . '/update') ?>" method="POST">
            <?= csrfField() ?>

            <div class="space-y-5">

                <div class="form-group mb-0">
                    <label for="title" class="form-label">Judul Kegiatan <span class="required">*</span></label>
                    <input type="text" id="title" name="title" required value="<?= e($activity['title']) ?>" class="form-control">
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="form-group mb-0">
                        <label for="organizer_id" class="form-label">Penyelenggara (Organizer) <span class="required">*</span></label>
                        <select id="organizer_id" name="organizer_id" required class="form-control">
                            <option value="">-- Pilih Organizer --</option>
                            <?php foreach ($organizers as $o): ?>
                                <option value="<?= $o['id'] ?>" <?= $activity['organizer_id'] == $o['id'] ? 'selected' : '' ?>><?= e($o['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group mb-0">
                        <label for="region_id" class="form-label">Wilayah Pelaksanaan <span class="required">*</span></label>
                        <select id="region_id" name="region_id" required class="form-control">
                            <option value="">-- Pilih Wilayah --</option>
                            <?php foreach ($regions as $r): ?>
                                <option value="<?= $r['id'] ?>" <?= $activity['region_id'] == $r['id'] ? 'selected' : '' ?>><?= e($r['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="form-group mb-0">
                        <label for="scheduled_at" class="form-label">Jadwal Pelaksanaan <span class="required">*</span></label>
                        <input type="datetime-local" id="scheduled_at" name="scheduled_at" required
                               value="<?= date('Y-m-d\TH:i', strtotime($activity['scheduled_at'] ?? 'now')) ?>"
                               class="form-control">
                    </div>

                    <div class="form-group mb-0">
                        <label for="max_participants" class="form-label">Kuota Maksimal Peserta</label>
                        <input type="number" id="max_participants" name="max_participants" min="1"
                               value="<?= e($activity['max_participants'] ?? '') ?>"
                               class="form-control">
                    </div>
                </div>

                <div class="form-group mb-0">
                    <label for="location_name" class="form-label">Nama / Patokan Lokasi</label>
                    <input type="text" id="location_name" name="location_name" value="<?= e($activity['location_name'] ?? '') ?>" class="form-control">
                </div>

                <div class="form-group mb-0">
                    <label for="address" class="form-label">Alamat Lengkap</label>
                    <textarea id="address" name="address" rows="2" class="form-control"><?= e($activity['address'] ?? '') ?></textarea>
                </div>

                <div class="form-group mb-0">
                    <label for="description" class="form-label">Deskripsi & Rencana Aksi <span class="required">*</span></label>
                    <textarea id="description" name="description" rows="4" required class="form-control"><?= e($activity['description'] ?? '') ?></textarea>
                </div>

                <div class="form-group mb-0">
                    <label for="status" class="form-label">Status Kegiatan</label>
                    <select id="status" name="status" class="form-control">
                        <option value="published" <?= $activity['status'] === 'published' ? 'selected' : '' ?>>Publikasikan (Published)</option>
                        <option value="draft" <?= $activity['status'] === 'draft' ? 'selected' : '' ?>>Draf (Draft)</option>
                        <option value="ongoing" <?= $activity['status'] === 'ongoing' ? 'selected' : '' ?>>Sedang Berlangsung (Ongoing)</option>
                        <option value="completed" <?= $activity['status'] === 'completed' ? 'selected' : '' ?>>Selesai (Completed)</option>
                    </select>
                </div>

                <div class="pt-4 flex items-center justify-end gap-3 border-t border-gray-100">
                    <a href="<?= url('admin/activities') ?>" class="btn btn-outline py-2 px-4 text-xs">Batal</a>
                    <button type="submit" class="btn btn-primary py-2 px-5 text-xs font-bold shadow-md">Simpan Perubahan</button>
                </div>

            </div>
        </form>
    </div>
</div>
