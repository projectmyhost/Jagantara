<?php $regActive = $registrationEnabled ?? isRegistrationEnabled(); ?>
<div class="min-h-[calc(100vh-200px)] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-lg w-full space-y-8 bg-white p-8 sm:p-10 rounded-2xl shadow-md border border-gray-100">

        <?php if (!$regActive): ?>
            <div class="text-center py-4">
                <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-amber-50 text-amber-600 border border-amber-200 shadow-sm mb-4">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                    </svg>
                </div>
                <h2 class="text-2xl font-bold text-gray-900 tracking-tight">Pendaftaran Ditutup</h2>
                <p class="mt-3 text-sm text-gray-600 leading-relaxed">
                    Mohon maaf, pendaftaran akun baru saat ini sedang dinonaktifkan sementara oleh administrator <?= e(setting('site_name', APP_NAME)) ?>.
                </p>
                <div class="mt-6 p-4 rounded-xl bg-gray-50 border border-gray-200 text-xs text-gray-500 text-left space-y-2">
                    <div class="flex items-center gap-2 text-gray-700 font-medium">
                        <svg class="w-4 h-4 text-emerald-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                        <span>Sudah memiliki akun terdaftar?</span>
                    </div>
                    <p class="pl-6">Warga yang sudah memiliki akun tetap dapat masuk dan menggunakan seluruh fitur pelaporan seperti biasa.</p>
                </div>
                <div class="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
                    <a href="<?= url('auth/login') ?>" class="btn btn-primary py-2.5 px-6 text-sm font-bold shadow-md">
                        Masuk ke Akun
                    </a>
                    <a href="<?= url('') ?>" class="btn btn-outline py-2.5 px-6 text-sm">
                        Kembali ke Beranda
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="text-center">
                <div class="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#1D4533] text-white shadow-sm mb-4">
                    <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/>
                    </svg>
                </div>
                <h2 class="text-2xl font-bold text-gray-900 tracking-tight">Daftar Akun Baru</h2>
                <p class="mt-2 text-sm text-gray-600">
                    Sudah memiliki akun?
                    <a href="<?= url('auth/login') ?>" class="font-semibold text-[#1D4533] hover:underline">
                        Masuk di sini
                    </a>
                </p>
            </div>

            <form class="mt-8 space-y-4" action="<?= url('auth/register') ?>" method="POST">
                <?= csrfField() ?>

                <div class="form-group">
                    <label for="full_name" class="form-label">Nama Lengkap <span class="required">*</span></label>
                    <input id="full_name" name="full_name" type="text" required
                           value="<?= e($values['full_name'] ?? '') ?>"
                           class="form-control"
                           placeholder="Contoh: Ahmad Hidayat">
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="form-group">
                        <label for="username" class="form-label">Username <span class="required">*</span></label>
                        <input id="username" name="username" type="text" required
                               value="<?= e($values['username'] ?? '') ?>"
                               class="form-control"
                               placeholder="username_anda">
                    </div>

                    <div class="form-group">
                        <label for="email" class="form-label">Alamat Email <span class="required">*</span></label>
                        <input id="email" name="email" type="email" autocomplete="email" required
                               value="<?= e($values['email'] ?? '') ?>"
                               class="form-control"
                               placeholder="nama@email.com">
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="form-group">
                        <label for="password" class="form-label">Password <span class="required">*</span></label>
                        <div class="relative">
                            <input id="password" name="password" type="password" required
                                   class="form-control pr-11"
                                   placeholder="Min. 8 karakter">
                            <button type="button" onclick="togglePassword('password', 'eye-pass')" tabindex="-1"
                                    class="absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-400 hover:text-gray-600 transition-colors">
                                <svg id="eye-pass" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                </svg>
                            </button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password_confirm" class="form-label">Ulangi Password <span class="required">*</span></label>
                        <div class="relative">
                            <input id="password_confirm" name="password_confirm" type="password" required
                                   class="form-control pr-11"
                                   placeholder="Konfirmasi password">
                            <button type="button" onclick="togglePassword('password_confirm', 'eye-confirm')" tabindex="-1"
                                    class="absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-400 hover:text-gray-600 transition-colors">
                                <svg id="eye-confirm" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="bg-gray-50 p-3 rounded-lg border border-gray-200 text-xs text-gray-600">
                    Dengan mendaftar, Anda menyetujui ketentuan komunitas Jagantara untuk menjaga keakuratan informasi dan etika pelaporan lingkungan.
                </div>

                <div class="pt-2">
                    <button type="submit" class="w-full btn btn-primary py-3 font-semibold shadow-sm text-base">
                        Daftar Sekarang
                    </button>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>

<script>
function togglePassword(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon  = document.getElementById(iconId);
    const isHidden = input.type === 'password';
    input.type = isHidden ? 'text' : 'password';
    if (isHidden) {
        icon.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/>`;
    } else {
        icon.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>`;
    }
}
</script>

