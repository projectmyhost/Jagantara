<div class="page-header">
    <div class="container">
        <h1>Peta Sebaran Laporan Lingkungan</h1>
        <p>Peta interaktif titik permasalahan kebersihan dan lingkungan di wilayah JABODETABEK.</p>
    </div>
</div>

<div class="container py-8">

    <div class="bg-white rounded-2xl border border-gray-200 p-4 sm:p-6 shadow-sm mb-6">

        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            <div>
                <h2 class="text-base font-bold text-gray-900">Sebaran Titik Laporan & Lokasi Pembersihan</h2>
                <p class="text-xs text-gray-500">Klik marker pada peta untuk melihat detail. Pin = Laporan, Lingkaran = Lokasi Pembersihan.</p>
            </div>

            <div class="flex flex-wrap items-center gap-2 text-xs">
                <div class="font-semibold text-gray-700">Status Laporan:</div>
                <span class="inline-flex items-center gap-1"><span class="w-3 h-3 rounded-full bg-yellow-400"></span> Menunggu</span>
                <span class="inline-flex items-center gap-1"><span class="w-3 h-3 rounded-full bg-blue-500"></span> Terverifikasi</span>
                <span class="inline-flex items-center gap-1"><span class="w-3 h-3 rounded-full bg-orange-500"></span> Ditangani</span>
                <span class="inline-flex items-center gap-1"><span class="w-3 h-3 rounded-full bg-emerald-500"></span> Selesai</span>
            </div>
        </div>

        <div class="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
            <div class="flex items-start gap-2">
                <svg class="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
                </svg>
                <div class="text-xs text-blue-800">
                    <strong class="font-semibold">Lokasi Pembersihan:</strong> Lingkaran berwarna menandai area yang sudah atau sedang dalam proses pembersihan oleh tim.
                </div>
            </div>
        </div>

        <div id="map-container" class="w-full"></div>

    </div>

    <div class="bg-gray-50 p-4 rounded-xl border border-gray-200 text-xs text-gray-600 space-y-1">
        <span class="font-bold text-gray-800 block">Keterangan Privasi Lokasi:</span>
        <p>
            Titik pada peta menunjukkan lokasi permasalahan lingkungan di tempat umum / ruang publik. Data pribadi pelapor dilindungi dan tidak ditampilkan pada peta.
        </p>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize map centered on Jakarta / Jabodetabek
    const defaultLat = <?= (float)setting('map_default_lat', '-6.2088') ?>;
    const defaultLng = <?= (float)setting('map_default_lng', '106.8456') ?>;
    const defaultZoom = <?= (int)setting('map_default_zoom', '11') ?>;

    const map = L.map('map-container').setView([defaultLat, defaultLng], defaultZoom);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    const allMarkers = [];

    // Fetch report markers from API
    fetch('<?= url('api/map-data') ?>')
        .then(response => response.json())
        .then(res => {
            if (res.success && res.data.length > 0) {
                res.data.forEach(item => {
                    if (!item.lat || !item.lng) return;

                    const marker = L.marker([item.lat, item.lng]).addTo(map);

                    const popupContent = `
                        <div style="min-width: 180px; font-family: sans-serif;">
                            <div style="font-size: 10px; font-weight: bold; background: #FEE2E2; color: #991B1B; padding: 4px 8px; border-radius: 4px; margin-bottom: 6px; display: inline-block;">
                                📍 LAPORAN WARGA
                            </div>
                            <span style="font-size: 10px; font-weight: bold; background: #F7EAE0; color: #5E3122; padding: 2px 6px; border-radius: 4px;">
                                ${item.category}
                            </span>
                            <h4 style="font-size: 13px; font-weight: bold; margin: 6px 0 4px; color: #111;">
                                ${item.title}
                            </h4>
                            <p style="font-size: 11px; color: #666; margin: 0 0 6px;">
                                Lokasi: ${item.location_name || item.region}
                            </p>
                            <div style="font-size: 11px; margin-bottom: 8px;">
                                Status: <strong>${item.status_label}</strong>
                            </div>
                            <a href="${item.url}" style="display: inline-block; background: #1D4533; color: white; text-decoration: none; font-size: 11px; font-weight: bold; padding: 4px 8px; border-radius: 4px;">
                                Buka Detail
                            </a>
                        </div>
                    `;

                    marker.bindPopup(popupContent);
                    allMarkers.push([item.lat, item.lng]);
                });
            }
        })
        .catch(err => {
            console.error('Failed to load map data:', err);
        });

    // Fetch cleanup location markers from API
    fetch('<?= url('api/cleanup-locations') ?>')
        .then(response => response.json())
        .then(res => {
            if (res.success && res.data.length > 0) {
                res.data.forEach(location => {
                    if (!location.latitude || !location.longitude) return;

                    // Create circle marker with color based on status
                    const circleMarker = L.circleMarker([location.latitude, location.longitude], {
                        radius: 12,
                        fillColor: location.statusColor,
                        color: '#fff',
                        weight: 2,
                        opacity: 1,
                        fillOpacity: 0.8
                    }).addTo(map);

                    const popupContent = `
                        <div style="min-width: 200px; font-family: sans-serif;">
                            <div style="font-size: 10px; font-weight: bold; background: #DBEAFE; color: #1E40AF; padding: 4px 8px; border-radius: 4px; margin-bottom: 6px; display: inline-block;">
                                🧹 LOKASI PEMBERSIHAN
                            </div>
                            <h4 style="font-size: 13px; font-weight: bold; margin: 6px 0 4px; color: #111;">
                                ${location.address}
                            </h4>
                            ${location.description ? `<p style="font-size: 11px; color: #666; margin: 4px 0;">${location.description}</p>` : ''}
                            <div style="margin: 8px 0;">
                                <span style="font-size: 11px; font-weight: bold; background: ${location.statusColor}; color: white; padding: 3px 8px; border-radius: 4px;">
                                    ${location.statusLabel}
                                </span>
                            </div>
                            <div style="font-size: 10px; color: #999; margin-top: 6px;">
                                Ditandai: ${new Date(location.created_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}
                            </div>
                        </div>
                    `;

                    circleMarker.bindPopup(popupContent);
                    allMarkers.push([location.latitude, location.longitude]);
                });

                // Fit bounds to show all markers if we have any
                if (allMarkers.length > 1) {
                    const bounds = L.latLngBounds(allMarkers);
                    map.fitBounds(bounds, { padding: [50, 50] });
                }
            }
        })
        .catch(err => {
            console.error('Failed to load cleanup locations:', err);
        });
});
</script>
