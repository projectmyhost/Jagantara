<?php

$rootDir = __DIR__;

// folder frontend sesuai project lo
$targetDirs = [
    'views',
    'public/css',
    'public/js'
];

// hanya file yang relevan
$extensions = ['css', 'php', 'js', 'html'];

function removeBlockComments($code) {
    return preg_replace('!/\*[\s\S]*?\*/!', '', $code);
}

function processFolder($dir, $extensions) {
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir)
    );

    foreach ($iterator as $file) {
        if ($file->isDir()) continue;

        $path = $file->getPathname();
        $ext = pathinfo($path, PATHINFO_EXTENSION);

        if (in_array($ext, $extensions)) {
            $content = file_get_contents($path);

            // skip kalau ga ada /* */
            if (strpos($content, '/*') === false) continue;

            $cleaned = removeBlockComments($content);

            file_put_contents($path, $cleaned);
            echo "Removed /* */: $path\n";
        }
    }
}

foreach ($targetDirs as $dir) {
    $fullPath = $rootDir . DIRECTORY_SEPARATOR . $dir;

    if (is_dir($fullPath)) {
        processFolder($fullPath, $extensions);
    }
}

echo "DONE: Semua komentar /* */ di frontend dihapus.\n";